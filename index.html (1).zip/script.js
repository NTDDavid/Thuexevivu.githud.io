function toggleMenu() {
    const menu = document.getElementById('menu');
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
}

function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.style.display = 'none';
    });

    const activePage = document.getElementById(pageId);
    if (activePage) {
        activePage.style.display = 'block';
    }
}

// Lắng nghe sự kiện nhấp chuột trên menu
document.querySelectorAll('.menu a').forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault();
        const pageId = this.getAttribute('href').substring(1);
        showPage(pageId);
        toggleMenu();
    });
});

// Hiển thị trang chủ mặc định khi tải trang
document.addEventListener('DOMContentLoaded', function() {
    showPage('home');
});
